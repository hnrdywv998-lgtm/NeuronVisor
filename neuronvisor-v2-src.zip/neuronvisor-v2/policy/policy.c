/* NeuronVisor v2 — policy/policy.c */
#include "policy.h"
#include "../gpu/gpu_partition.h"
#include "../hal/serial.h"
#include "../hal/vga.h"

policy_state_t g_policy;

void policy_init(void) {
    memset(&g_policy, 0, sizeof(g_policy));
    g_policy.global_policy = SCHED_FAIR;

    /* Default: all partitions get FAIR scheduling, equal priority */
    uint32_t n = gpu_partition_count();
    if (n == 0) n = 1;
    for (uint32_t i = 0; i < n && i < 8; i++) {
        g_policy.sched[i].partition_id     = i;
        g_policy.sched[i].policy           = SCHED_FAIR;
        g_policy.sched[i].priority         = 128;
        g_policy.sched[i].slo_latency_ms   = 200;  /* 200ms default SLO */
    }

    /*
     * Bootstrap auth token: in production this would come from a TPM or
     * a sealed secret. Here we use a fixed token for testability.
     * Anyone holding this token can use all partitions.
     */
    uint8_t bootstrap_token[TOKEN_LEN] = {
        0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE,
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
        0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10,
        0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
    };
    memcpy(g_policy.tokens[0].token, bootstrap_token, TOKEN_LEN);
    g_policy.tokens[0].allowed_partitions = 0xFF; /* all partitions */
    g_policy.tokens[0].can_load_model     = 1;
    g_policy.tokens[0].can_run_inference  = 1;
    g_policy.tokens[0].can_checkpoint     = 1;
    g_policy.tokens[0].active             = 1;

    serial_puts("[POLICY] Initialised: FAIR scheduling, SLO=200ms\n");
    serial_puts("[POLICY] Bootstrap auth token installed\n");
}

void policy_set_sched(uint32_t partition_id, sched_policy_t p, uint8_t priority) {
    if (partition_id >= 8) return;
    g_policy.sched[partition_id].policy   = p;
    g_policy.sched[partition_id].priority = priority;
    serial_puts("[POLICY] Partition ");
    serial_putd(partition_id);
    serial_puts(": sched=");
    serial_putd(p);
    serial_puts(" pri=");
    serial_putd(priority);
    serial_puts("\n");
}

int policy_auth_check(const uint8_t *token, uint32_t partition_id, uint8_t op) {
    if (!token) return -1;
    for (uint32_t i = 0; i < POLICY_MAX_TOKENS; i++) {
        if (!g_policy.tokens[i].active) continue;
        uint8_t match = 1;
        for (int j = 0; j < TOKEN_LEN; j++) {
            if (g_policy.tokens[i].token[j] != token[j]) { match = 0; break; }
        }
        if (!match) continue;
        /* Token found — check permissions */
        if (!(g_policy.tokens[i].allowed_partitions & (1u << partition_id))) return -1;
        if (op == 1 && !g_policy.tokens[i].can_load_model)    return -1;
        if (op == 2 && !g_policy.tokens[i].can_run_inference)  return -1;
        if (op == 3 && !g_policy.tokens[i].can_checkpoint)    return -1;
        return 0;  /* Authorised */
    }
    serial_puts("[POLICY] AUTH FAIL: unknown token\n");
    return -1;
}

void policy_record_inference(uint32_t partition_id, uint32_t req_id,
                              uint32_t latency_us, uint32_t in_tok, uint32_t out_tok) {
    inference_metric_t *m = &g_policy.metrics[g_policy.metric_head % METRIC_RING_SIZE];
    m->partition_id  = partition_id;
    m->request_id    = req_id;
    m->latency_us    = latency_us;
    m->input_tokens  = in_tok;
    m->output_tokens = out_tok;

    sched_entry_t *s = &g_policy.sched[partition_id];
    s->tokens_processed   += (in_tok + out_tok);
    s->total_latency_us   += latency_us;
    s->requests_served++;

    /* SLO check */
    uint32_t slo_us = s->slo_latency_ms * 1000;
    m->slo_met = (slo_us == 0 || latency_us <= slo_us) ? 1 : 0;
    if (!m->slo_met) {
        s->requests_dropped++;
        serial_puts("[POLICY] SLO VIOLATION: partition=");
        serial_putd(partition_id);
        serial_puts(" latency=");
        serial_putd(latency_us / 1000);
        serial_puts("ms (limit=");
        serial_putd(s->slo_latency_ms);
        serial_puts("ms)\n");
    }

    g_policy.metric_head++;
    if (g_policy.metric_count < METRIC_RING_SIZE) g_policy.metric_count++;
}

/*
 * policy_next_partition() — weighted fair queue scheduler.
 * Returns the partition with the lowest tokens_processed / weight ratio.
 * This ensures no partition gets starved even if requests arrive unevenly.
 */
uint32_t policy_next_partition(void) {
    uint32_t n = gpu_partition_count();
    if (n == 0) return 0;

    uint32_t best = 0;
    uint64_t best_score = (uint64_t)-1;
    for (uint32_t i = 0; i < n; i++) {
        /* Lower priority number = higher priority = lower effective score */
        uint64_t score = g_policy.sched[i].tokens_processed
                       * (uint64_t)(g_policy.sched[i].priority + 1);
        if (score < best_score) { best_score = score; best = i; }
    }
    return best;
}

void policy_print_stats(void) {
    uint32_t n = gpu_partition_count();
    if (n == 0) n = 1;
    vga_puts("  Scheduling stats:\n");
    for (uint32_t i = 0; i < n; i++) {
        sched_entry_t *s = &g_policy.sched[i];
        vga_puts("    Part ");
        vga_putd(i);
        vga_puts(": served=");
        vga_putd((uint32_t)s->requests_served);
        vga_puts(" dropped=");
        vga_putd((uint32_t)s->requests_dropped);
        vga_puts(" tokens=");
        vga_putd((uint32_t)(s->tokens_processed / 1000));
        vga_puts("K");
        if (s->requests_served > 0) {
            vga_puts(" avg_lat=");
            vga_putd((uint32_t)(s->total_latency_us / s->requests_served / 1000));
            vga_puts("ms");
        }
        vga_puts("\n");
    }
}

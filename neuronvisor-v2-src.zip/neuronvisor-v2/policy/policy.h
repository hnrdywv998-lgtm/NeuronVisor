/*
 * NeuronVisor v2 — policy/policy.h + policy/policy.c
 *
 * LAYER 4 — Policy Engine + Observability
 *
 * The v1 review correctly identified that 4 hypercalls is philosophically
 * elegant but operationally insufficient. Real AI systems also need:
 *
 *   - Authentication (who is allowed to load a model?)
 *   - Scheduling policy (priority, preemption, SLO enforcement)
 *   - Checkpoint replication (where do checkpoints go?)
 *   - Failure recovery (what happens when a partition crashes?)
 *   - Observability (metrics, logs, traces)
 *   - Secrets management (API keys, model weights DRM)
 *
 * This layer handles all of those ABOVE the isolation layer.
 * Crucially, it is OUTSIDE the trusted core (below the trust boundary)
 * so a bug here cannot compromise isolation.
 *
 * The design maps to the "Micro-Hypervisor + Policy Engine" split:
 *   Trusted:    iommu + micro-hypervisor kernel (minimal, auditable)
 *   Untrusted:  policy engine (complex, but contained)
 *
 * This is the same principle as SELinux (policy separate from enforcement)
 * or Xen's toolstack (xl in dom0, not in the hypervisor).
 */

#ifndef POLICY_H
#define POLICY_H
#include "../kernel/kernel.h"

/* ── Scheduling policy ────────────────────────────────────────────────── */

typedef enum {
    SCHED_FIFO       = 0,   /* First-in, first-out (simple)            */
    SCHED_PRIORITY   = 1,   /* Strict priority queue                   */
    SCHED_FAIR       = 2,   /* Weighted fair queueing (default)        */
    SCHED_SLO        = 3,   /* Latency SLO enforcement                 */
} sched_policy_t;

/* Per-partition scheduling descriptor */
typedef struct {
    uint32_t      partition_id;
    sched_policy_t policy;
    uint8_t       priority;     /* 0 (highest) – 255 (lowest) */
    uint32_t      slo_latency_ms;   /* target P99 latency, 0=none */
    uint64_t      tokens_processed;
    uint64_t      total_latency_us; /* for P99 tracking */
    uint64_t      requests_served;
    uint64_t      requests_dropped; /* SLO violations */
} sched_entry_t;

/* ── Authentication ───────────────────────────────────────────────────── */

#define POLICY_MAX_TOKENS   16
#define TOKEN_LEN           32

typedef struct {
    uint8_t  token[TOKEN_LEN];  /* Opaque auth token (SHA-256 of secret) */
    uint32_t allowed_partitions; /* Bitmask of allowed partition IDs      */
    uint8_t  can_load_model;
    uint8_t  can_run_inference;
    uint8_t  can_checkpoint;
    uint8_t  active;
} auth_token_t;

/* ── Observability ────────────────────────────────────────────────────── */

#define METRIC_RING_SIZE    64

typedef struct {
    uint64_t timestamp_us;
    uint32_t partition_id;
    uint32_t request_id;
    uint32_t latency_us;
    uint32_t input_tokens;
    uint32_t output_tokens;
    uint8_t  slo_met;
} inference_metric_t;

/* ── Policy engine state ──────────────────────────────────────────────── */
typedef struct {
    sched_entry_t     sched[8];
    auth_token_t      tokens[POLICY_MAX_TOKENS];
    inference_metric_t metrics[METRIC_RING_SIZE];
    uint32_t          metric_head;
    uint32_t          metric_count;
    sched_policy_t    global_policy;
} policy_state_t;

void     policy_init(void);
void     policy_set_sched(uint32_t partition_id, sched_policy_t p, uint8_t priority);
int      policy_auth_check(const uint8_t *token, uint32_t partition_id, uint8_t op);
void     policy_record_inference(uint32_t partition_id, uint32_t req_id,
                                  uint32_t latency_us, uint32_t in_tok, uint32_t out_tok);
void     policy_print_stats(void);
uint32_t policy_next_partition(void);   /* Scheduler: pick next partition to run */

extern policy_state_t g_policy;
#endif /* POLICY_H */

/* NeuronVisor v2 — cuda_compat/cuda_compat.c */
#include "cuda_compat.h"
#include "../gpu/gpu_partition.h"
#include "../hal/serial.h"
#include "../hal/vga.h"

static uint8_t       shim_initialised = 0;
static nv_cuda_ctx_t cuda_contexts[NV_MAX_CUDA_CONTEXTS];
static uint32_t      ctx_count = 0;

/*
 * One virtual CUdevice per GPU partition.
 * ordinal 0 -> partition 0, ordinal 1 -> partition 1, etc.
 */
void cuda_compat_init(void) {
    memset(cuda_contexts, 0, sizeof(cuda_contexts));
    ctx_count = 0;
    shim_initialised = 1;
    serial_puts("[CUDA-COMPAT] Shim initialised. Virtual devices: ");
    serial_putd(gpu_partition_count());
    serial_puts("\n");
    serial_puts("[CUDA-COMPAT] NOTE: shim stubs only — real GPU firmware\n");
    serial_puts("[CUDA-COMPAT]   integration requires nvidia-open-kernel-module.\n");
}

CUresult cuInit(unsigned int flags) {
    (void)flags;
    if (!shim_initialised) return CUDA_ERROR_NOT_INITIALIZED;
    serial_puts("[CUDA-COMPAT] cuInit() -> SUCCESS\n");
    return CUDA_SUCCESS;
}

CUresult cuDeviceGetCount(int *count) {
    if (!count) return CUDA_ERROR_INVALID_VALUE;
    *count = (int)gpu_partition_count();
    if (*count == 0) *count = 1;  /* Simulation: always at least 1 virtual device */
    return CUDA_SUCCESS;
}

CUresult cuDeviceGet(CUdevice *device, int ordinal) {
    if (!device) return CUDA_ERROR_INVALID_VALUE;
    uint32_t n = gpu_partition_count();
    if (n == 0) n = 1;
    if ((uint32_t)ordinal >= n) return CUDA_ERROR_INVALID_VALUE;
    *device = (CUdevice)ordinal;
    return CUDA_SUCCESS;
}

CUresult cuDeviceGetName(char *name, int len, CUdevice dev) {
    if (!name || len <= 0) return CUDA_ERROR_INVALID_VALUE;
    gpu_partition_t *p = gpu_partition_get((uint32_t)dev);
    const char *src = p ? "NeuronVisor GPU Partition" : "NeuronVisor Simulated Device";
    int i = 0;
    while (src[i] && i < len - 1) { name[i] = src[i]; i++; }
    name[i] = '\0';
    return CUDA_SUCCESS;
}

CUresult cuDeviceTotalMem(size_t *bytes, CUdevice dev) {
    if (!bytes) return CUDA_ERROR_INVALID_VALUE;
    gpu_partition_t *p = gpu_partition_get((uint32_t)dev);
    *bytes = p ? (size_t)p->hbm_size_mb * 1024 * 1024 : (size_t)2 * 1024 * 1024 * 1024;
    return CUDA_SUCCESS;
}

CUresult cuCtxCreate(CUcontext *ctx, unsigned int flags, CUdevice dev) {
    (void)flags;
    if (!ctx) return CUDA_ERROR_INVALID_VALUE;
    if (ctx_count >= NV_MAX_CUDA_CONTEXTS) return CUDA_ERROR_OUT_OF_MEMORY;

    nv_cuda_ctx_t *c = &cuda_contexts[ctx_count];
    c->partition_id    = (uint32_t)dev;
    c->iommu_domain_id = (uint32_t)dev;  /* 1:1 mapping for prototype */
    c->allocated_bytes = 0;
    c->active          = 1;
    c->ctx             = (CUcontext)(uintptr_t)(0xC0DE0000 + ctx_count);
    *ctx               = c->ctx;
    ctx_count++;

    serial_puts("[CUDA-COMPAT] cuCtxCreate() partition=");
    serial_putd(c->partition_id);
    serial_puts(" ctx=");
    serial_puth((uint64_t)(uintptr_t)c->ctx);
    serial_puts("\n");
    return CUDA_SUCCESS;
}

CUresult cuCtxDestroy(CUcontext ctx) {
    for (uint32_t i = 0; i < ctx_count; i++) {
        if (cuda_contexts[i].ctx == ctx) {
            cuda_contexts[i].active = 0;
            serial_puts("[CUDA-COMPAT] cuCtxDestroy() ok\n");
            return CUDA_SUCCESS;
        }
    }
    return CUDA_ERROR_INVALID_VALUE;
}

/* Memory allocation: routed to the partition's HBM region via tensor MM */
CUresult cuMemAlloc(CUdeviceptr *dptr, size_t bytesize) {
    if (!dptr) return CUDA_ERROR_INVALID_VALUE;
    /*
     * In a real implementation this calls into the GPU's memory allocator
     * (via the NVIDIA open kernel module) within the partition's IOMMU domain.
     * Here we return a synthetic pointer for ABI compatibility.
     */
    static uint64_t fake_hbm_ptr = 0x100000000ULL;  /* Above 4GB */
    *dptr = (CUdeviceptr)fake_hbm_ptr;
    fake_hbm_ptr += (bytesize + 255) & ~255ULL;      /* 256-byte align */
    serial_puts("[CUDA-COMPAT] cuMemAlloc(");
    serial_putd((uint32_t)(bytesize / 1024));
    serial_puts("KB) -> ");
    serial_puth(*dptr);
    serial_puts("\n");
    return CUDA_SUCCESS;
}

CUresult cuMemFree(CUdeviceptr dptr) {
    /* Bump allocator: no real free in prototype */
    serial_puts("[CUDA-COMPAT] cuMemFree(");
    serial_puth(dptr);
    serial_puts(")\n");
    return CUDA_SUCCESS;
}

CUresult cuMemcpyHtoD(CUdeviceptr dst, const void *src, size_t n) {
    (void)dst; (void)src; (void)n;
    /* Stub: real impl does DMA from pinned host memory to partition HBM */
    return CUDA_SUCCESS;
}

CUresult cuMemcpyDtoH(void *dst, CUdeviceptr src, size_t n) {
    (void)dst; (void)src; (void)n;
    /* Stub: real impl does DMA from partition HBM to host memory */
    return CUDA_SUCCESS;
}

CUresult cuStreamCreate(CUstream *stream, unsigned int flags) {
    (void)flags;
    if (!stream) return CUDA_ERROR_INVALID_VALUE;
    static uint32_t stream_id = 1;
    *stream = (CUstream)(uintptr_t)(0x57EA0000ULL + stream_id++);
    return CUDA_SUCCESS;
}

CUresult cuStreamSynchronize(CUstream stream) {
    (void)stream;
    __asm__ volatile("pause");  /* No-op in prototype */
    return CUDA_SUCCESS;
}

CUresult cuStreamDestroy(CUstream stream) {
    (void)stream;
    return CUDA_SUCCESS;
}

uint32_t nv_ctx_partition_id(CUcontext ctx) {
    for (uint32_t i = 0; i < ctx_count; i++)
        if (cuda_contexts[i].ctx == ctx) return cuda_contexts[i].partition_id;
    return (uint32_t)-1;
}

void cuda_compat_status(void) {
    vga_puts("  CUDA shim: ");
    vga_putd(ctx_count);
    vga_puts(" contexts, ");
    vga_putd((uint32_t)gpu_partition_count());
    vga_puts(" virtual devices\n");
    if (!shim_initialised) {
        vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
        vga_puts("  WARNING: shim not initialised\n");
        vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
    }
}

/*
 * NeuronVisor v2 — cuda_compat/cuda_compat.h
 *
 * LAYER 3 — CUDA Compatibility Adapter
 *
 * This addresses the biggest strategic gap in v1, which the review
 * called out directly:
 *
 *   "You cannot realistically bypass CUDA easily.
 *    Without CUDA compatibility: PyTorch breaks, TensorRT breaks,
 *    inference runtimes break."
 *
 * NeuronVisor does NOT try to replace CUDA. Instead this layer
 * provides a thin shim that:
 *
 *   1. Exposes the subset of the CUDA Driver API needed to bootstrap
 *      existing frameworks (cuInit, cuDeviceGet, cuMemAlloc, etc.)
 *
 *   2. Forwards those calls to the GPU's actual firmware/hardware
 *      through our GPU partition manager, so isolation is maintained
 *      while staying ABI-compatible.
 *
 *   3. Makes the isolation layer transparent: PyTorch running inside
 *      a NeuronVisor VM sees a standard CUDA device. It does not need
 *      to know about partitions, hypercalls, or IOMMU domains.
 *
 * WHAT THIS IS NOT:
 *   - A full CUDA reimplementation (that is millions of lines)
 *   - A solution for consumer GPUs without firmware cooperation
 *   - A way to run arbitrary CUDA kernels without the proprietary
 *     NVIDIA driver stack underneath
 *
 * STRATEGIC POSITION:
 *   NeuronVisor sits ABOVE the NVIDIA open-kernel-module (NVK/NVrm).
 *   The open kernel module handles the real hardware communication.
 *   NeuronVisor adds the isolation, scheduling, and tensor-aware
 *   memory management ON TOP of that — not instead of it.
 *
 *   This is architecturally similar to:
 *     Xen + CUDA (dom0 holds the real driver, domU sees a virtual device)
 *
 * HONEST STATUS:
 *   The shim stubs here compile and produce the correct symbol names.
 *   Connecting them to real GPU firmware is the primary remaining
 *   engineering work and requires NVIDIA open-kernel-module integration.
 */

#ifndef CUDA_COMPAT_H
#define CUDA_COMPAT_H
#include "../kernel/kernel.h"

/* Minimal CUDA driver API types (ABI-compatible with real CUDA) */
typedef int          CUresult;
typedef uint64_t     CUdeviceptr;
typedef int          CUdevice;
typedef void*        CUcontext;
typedef void*        CUstream;
typedef void*        CUmodule;
typedef void*        CUfunction;

#define CUDA_SUCCESS                    0
#define CUDA_ERROR_NOT_INITIALIZED      3
#define CUDA_ERROR_NO_DEVICE            100
#define CUDA_ERROR_OUT_OF_MEMORY        2
#define CUDA_ERROR_INVALID_VALUE        1
#define CUDA_ERROR_NOT_SUPPORTED        801

/* Our extension: which NeuronVisor partition backs this context */
typedef struct {
    CUcontext   ctx;
    uint32_t    partition_id;
    uint32_t    iommu_domain_id;
    uint64_t    allocated_bytes;
    uint8_t     active;
} nv_cuda_ctx_t;

#define NV_MAX_CUDA_CONTEXTS    8

/*
 * cuda_compat_init() — initialise the shim layer.
 * Registers our partition-backed virtual CUDA devices.
 * One virtual CUdevice per GPU partition.
 */
void cuda_compat_init(void);

/*
 * The following match the real CUDA Driver API signatures exactly,
 * so binary-compatible frameworks can be loaded without modification.
 */
CUresult cuInit(unsigned int flags);
CUresult cuDeviceGetCount(int *count);
CUresult cuDeviceGet(CUdevice *device, int ordinal);
CUresult cuDeviceGetName(char *name, int len, CUdevice dev);
CUresult cuDeviceTotalMem(size_t *bytes, CUdevice dev);
CUresult cuCtxCreate(CUcontext *ctx, unsigned int flags, CUdevice dev);
CUresult cuCtxDestroy(CUcontext ctx);
CUresult cuMemAlloc(CUdeviceptr *dptr, size_t bytesize);
CUresult cuMemFree(CUdeviceptr dptr);
CUresult cuMemcpyHtoD(CUdeviceptr dst, const void *src, size_t n);
CUresult cuMemcpyDtoH(void *dst, CUdeviceptr src, size_t n);
CUresult cuStreamCreate(CUstream *stream, unsigned int flags);
CUresult cuStreamSynchronize(CUstream stream);
CUresult cuStreamDestroy(CUstream stream);

/* NeuronVisor extension: query which partition a context is mapped to */
uint32_t nv_ctx_partition_id(CUcontext ctx);

/* Print shim status */
void cuda_compat_status(void);

#endif /* CUDA_COMPAT_H */

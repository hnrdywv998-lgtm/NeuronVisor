; NeuronVisor - Multiboot2 boot entry
; Targets: x86_64, boots via GRUB or any Multiboot2-compliant bootloader

BITS 32

; Multiboot2 header constants
MULTIBOOT2_MAGIC    equ 0xE85250D6
MULTIBOOT2_ARCH     equ 0           ; i386 protected mode
MULTIBOOT2_HDRLEN   equ (mb2_header_end - mb2_header_start)
MULTIBOOT2_CHECKSUM equ -(MULTIBOOT2_MAGIC + MULTIBOOT2_ARCH + MULTIBOOT2_HDRLEN)

section .multiboot2
align 8
mb2_header_start:
    dd MULTIBOOT2_MAGIC
    dd MULTIBOOT2_ARCH
    dd MULTIBOOT2_HDRLEN
    dd MULTIBOOT2_CHECKSUM
    ; Framebuffer tag (request text mode)
    dw 5            ; type: framebuffer
    dw 0            ; flags
    dd 20           ; size
    dd 0            ; width  (0 = no preference)
    dd 0            ; height (0 = no preference)
    dd 0            ; depth  (0 = no preference)
    align 8
    ; End tag
    dw 0
    dw 0
    dd 8
mb2_header_end:

section .bss
align 16
stack_bottom:
    resb 65536      ; 64 KiB initial stack
stack_top:

; Page tables for identity mapping first 2 GiB
align 4096
pml4_table:  resb 4096
pdp_table:   resb 4096
pd_table:    resb 4096

section .text
global _start
extern kernel_main

_start:
    ; Set up our stack
    mov esp, stack_top

    ; Save multiboot info pointer (ebx = multiboot2 info struct)
    push 0
    push ebx

    ; Verify we have SSE2 (required for FP in long mode)
    mov eax, 1
    cpuid
    test edx, 1<<26     ; SSE2 bit
    jz .no_sse2

    ; Check for 64-bit long mode support
    mov eax, 0x80000001
    cpuid
    test edx, 1<<29     ; Long Mode bit
    jz .no_long_mode

    ; Enable SSE
    mov eax, cr0
    and ax, 0xFFFB      ; clear EM (coprocessor emulation)
    or ax, 0x2          ; set MP (monitor coprocessor)
    mov cr0, eax
    mov eax, cr4
    or eax, 3 << 9      ; OSFXSR + OSXMMEXCPT
    mov cr4, eax

    ; Build page tables (identity map 0-2GiB with 2MiB huge pages)
    ; PML4[0] -> PDP
    mov eax, pdp_table
    or eax, 0x3        ; present + writable
    mov [pml4_table], eax

    ; PDP[0] -> PD
    mov eax, pd_table
    or eax, 0x3
    mov [pdp_table], eax

    ; PD: 512 entries, each covering 2MiB
    mov ecx, 0
.map_pd:
    mov eax, 0x200000   ; 2 MiB
    mul ecx
    or eax, 0x83        ; present + writable + huge page
    mov [pd_table + ecx * 8], eax
    inc ecx
    cmp ecx, 512
    jne .map_pd

    ; Load PML4 into CR3
    mov eax, pml4_table
    mov cr3, eax

    ; Enable PAE
    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    ; Enable long mode in EFER MSR
    mov ecx, 0xC0000080
    rdmsr
    or eax, 1 << 8      ; LME bit
    wrmsr

    ; Enable paging (activates long mode)
    mov eax, cr0
    or eax, 1 << 31
    mov cr0, eax

    ; Far jump to 64-bit code segment
    lgdt [gdt64.pointer]
    jmp gdt64.code:long_mode_start

.no_sse2:
    mov esi, err_no_sse2
    jmp boot_error

.no_long_mode:
    mov esi, err_no_lm
    jmp boot_error

; Print error to VGA and halt
boot_error:
    mov edi, 0xB8000
    mov ah, 0x4F        ; white on red
.print:
    lodsb
    test al, al
    jz .halt
    stosw
    jmp .print
.halt:
    cli
    hlt
    jmp .halt

; 64-bit GDT
align 8
gdt64:
    dq 0                            ; null descriptor
.code: equ $ - gdt64
    dq (1<<43)|(1<<44)|(1<<47)|(1<<53)  ; code segment
.pointer:
    dw $ - gdt64 - 1
    dd gdt64

err_no_sse2:  db "NeuronVisor: SSE2 required. CPU too old.", 0
err_no_lm:    db "NeuronVisor: 64-bit long mode not supported.", 0

; --- 64-bit code ---
BITS 64
long_mode_start:
    ; Zero all segment registers
    mov ax, 0
    mov ss, ax
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    ; Retrieve multiboot2 info pointer (was pushed as 32-bit)
    pop rdi             ; multiboot2 info pointer -> first argument to kernel_main
    call kernel_main

    ; Should never return
    cli
.halt:
    hlt
    jmp .halt

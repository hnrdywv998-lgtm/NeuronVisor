/*
 * NeuronVisor — kernel/kernel.h
 * Core types, constants, and declarations shared across all subsystems.
 */

#ifndef KERNEL_H
#define KERNEL_H

/* ── Freestanding integer types ───────────────────────────────────────── */
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef signed char        int8_t;
typedef signed short       int16_t;
typedef signed int         int32_t;
typedef signed long long   int64_t;
typedef uint64_t           size_t;
typedef uint64_t           uintptr_t;

#define NULL  ((void*)0)
#define TRUE  1
#define FALSE 0

/* ── Compiler hints ────────────────────────────────────────────────────── */
#define PACKED      __attribute__((packed))
#define NORETURN    __attribute__((noreturn))
#define ALIGN(n)    __attribute__((aligned(n)))
#define UNUSED(x)   ((void)(x))

/* ── Kernel subsystem declarations ────────────────────────────────────── */

/* Forward declaration of gpu_device_t for use in kernel.h */
typedef struct gpu_device gpu_device_t;

/* Called from main() after all inits */
void scheduler_loop(void);
uint32_t run_self_tests(void);
void print_system_summary(gpu_device_t *gpu);
NORETURN void kernel_halt(void);

/* ── GPU device descriptor ─────────────────────────────────────────────  */
struct gpu_device {
    uint16_t    vendor_id;
    uint16_t    device_id;
    const char *vendor_name;
    const char *name;
    uint32_t    hbm_mb;         /* High-bandwidth memory in MiB */
    uint32_t    sm_count;       /* Streaming multiprocessor count */
    uint8_t     mig_capable;    /* Supports Multi-Instance GPU */
    uint8_t     bus;
    uint8_t     slot;
    uint8_t     func;
};

/* ── I/O port helpers ──────────────────────────────────────────────────── */
static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t val;
    __asm__ volatile("inb %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

static inline void outl(uint16_t port, uint32_t val) {
    __asm__ volatile("outl %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint32_t inl(uint16_t port) {
    uint32_t val;
    __asm__ volatile("inl %1, %0" : "=a"(val) : "Nd"(port));
    return val;
}

/* ── Memory helpers ────────────────────────────────────────────────────── */
static inline void memset(void *dst, uint8_t val, size_t len) {
    uint8_t *p = (uint8_t *)dst;
    while (len--) *p++ = val;
}

static inline void memcpy(void *dst, const void *src, size_t len) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (len--) *d++ = *s++;
}

static inline size_t strlen(const char *s) {
    size_t n = 0;
    while (*s++) n++;
    return n;
}

#endif /* KERNEL_H */

/*
 * NeuronVisor v2 — kernel/main.c
 */
#include "kernel.h"
#include "../hal/serial.h"
#include "../hal/pci.h"
#include "../hal/vga.h"
#include "../iommu/iommu.h"
#include "../mm/tensor_mm.h"
#include "../gpu/gpu_partition.h"
#include "../cuda_compat/cuda_compat.h"
#include "../policy/policy.h"
#include "../vm/vm.h"

#define NV_VERSION "0.2.0"

static void print_banner(void) {
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("\n  NeuronVisor — AI-Native Secure Micro-Hypervisor\n");
    vga_puts("  v"); vga_puts(NV_VERSION); vga_puts("  [RESEARCH PROTOTYPE]\n\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
}

static void phase(const char *layer, const char *name) {
    vga_set_color(VGA_COLOR_DARK_GRAY, VGA_COLOR_BLACK);
    vga_puts("["); vga_puts(layer); vga_puts("] ");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
    vga_puts(name); vga_puts(" ... ");
    serial_puts("["); serial_puts(layer); serial_puts("] ");
    serial_puts(name); serial_puts("\n");
}

static void ok(void) {
    vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
    vga_puts("OK\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
}

static void warn(const char *msg) {
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts("WARN "); vga_puts(msg); vga_puts("\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
    serial_puts("[WARN] "); serial_puts(msg); serial_puts("\n");
}

void kernel_main(uint64_t mb2_info_ptr) {
    serial_init(SERIAL_COM1, SERIAL_BAUD_115200);
    serial_puts("\n[NeuronVisor v2] Serial online\n");
    vga_init();
    print_banner();

    if (mb2_info_ptr == 0) {
        vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
        vga_puts("FATAL: no multiboot2 info\n");
        kernel_halt();
    }

    /* Layer 1 — Trusted core */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 1: Trusted micro-hypervisor core --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L1", "PCI bus enumeration");
    pci_init();
    vga_putd(pci_enumerate()); vga_puts(" devices "); ok();

    phase("L1", "IOMMU init");
    iommu_init();
    if (iommu_is_hardware_enforced()) {
        vga_puts("hw-enforced ");
    } else {
        vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
        vga_puts("soft-only ");
        vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
    }
    ok();

    phase("L1", "GPU discovery");
    gpu_device_t *gpu = gpu_discover();
    if (!gpu) warn("no GPU -- simulation mode");
    else { vga_puts(gpu->name); vga_puts(" "); ok(); }

    /* Layer 2a — Secure GPU manager */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 2a: Secure GPU manager --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L2a", "GPU partition carving + IOMMU domains");
    uint32_t nparts = gpu ? gpu_partition_init(gpu) : 1;
    for (uint32_t i = 0; i < nparts; i++) {
        gpu_partition_t *p = gpu_partition_get(i);
        if (!p) continue;
        uint64_t base  = (uint64_t)p->hbm_start_mb * 1024 * 1024;
        uint64_t limit = base + (uint64_t)p->hbm_size_mb * 1024 * 1024;
        uint32_t dom   = iommu_create_domain(base, limit);
        iommu_map_range(dom, base, (uint64_t)p->hbm_size_mb * 1024 * 1024);
        if (gpu) iommu_bind_device(dom, gpu->bus, gpu->slot, gpu->func);
    }
    vga_putd(nparts); vga_puts(" partitions + "); vga_putd(nparts); vga_puts(" IOMMU domains "); ok();

    /* Layer 2b — AI runtime */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 2b: AI runtime --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L2b", "Tensor memory manager");
    tmm_init(gpu);
    vga_putd(tmm_available_mb()); vga_puts("MB "); ok();

    /* Layer 3 — CUDA compat */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 3: CUDA compatibility shim --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L3", "CUDA driver ABI shim");
    cuda_compat_init();
    int devcnt = 0;
    cuInit(0); cuDeviceGetCount(&devcnt);
    vga_putd((uint32_t)devcnt); vga_puts(" virtual CUDA devices "); ok();

    /* Layer 4 — Policy */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 4: Policy engine --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L4", "Auth + scheduler + SLO tracker");
    policy_init(); ok();

    /* Layer 5 — VM/hypercall */
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("  -- Layer 5: Hypercall ABI --\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    phase("L5", "VM hypercall subsystem");
    vm_init(); ok();

    /* Self-tests */
    phase("TEST", "Self-test suite");
    uint32_t passed = run_self_tests();
    vga_putd(passed); vga_puts(" tests passed "); ok();

    print_system_summary(gpu);
    vga_puts("\n  Entering inference scheduling loop (FAIR policy)...\n\n");
    serial_puts("[READY] NeuronVisor v2 operational\n");
    scheduler_loop();
    kernel_halt();
}

void print_system_summary(gpu_device_t *gpu) {
    vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    vga_puts("\n  -- System Summary ----\n");
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    vga_puts("  CPU:    x86-64 long mode\n");
    vga_puts("  IOMMU:  ");
    if (iommu_is_hardware_enforced()) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_puts("Hardware enforced (SECURE)\n");
    } else {
        vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
        vga_puts("Soft isolation (NOT SECURE for multi-tenant)\n");
    }
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

    if (gpu) {
        vga_puts("  GPU:    "); vga_puts(gpu->name);
        vga_puts(" ["); vga_puts(gpu->vendor_name); vga_puts("]\n");
        vga_puts("  HBM:    "); vga_putd(gpu->hbm_mb); vga_puts(" MB  SMs: "); vga_putd(gpu->sm_count); vga_puts("\n");
        vga_puts("  Parts:  "); vga_putd(gpu_partition_count()); vga_puts(" isolated\n");
    } else {
        vga_puts("  GPU:    None (simulation mode)\n");
    }
    vga_puts("  CUDA:   ABI shim active\n");
    vga_puts("  Sched:  FAIR, SLO=200ms P99\n");
    vga_puts("  Tensor: "); vga_putd(tmm_available_mb()); vga_puts(" MB\n");
}

void kernel_halt(void) {
    serial_puts("[HALT]\n");
    __asm__ volatile("cli");
    for (;;) __asm__ volatile("hlt");
}

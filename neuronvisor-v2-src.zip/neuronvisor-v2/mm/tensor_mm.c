/* NeuronVisor — mm/tensor_mm.c */
#include "tensor_mm.h"
#include "../hal/serial.h"
#include "../hal/vga.h"

/*
 * Simple bump allocator backed by a static pool.
 * In a real implementation this would manage GPU HBM directly.
 * For this prototype we use a 64 MiB static region to demonstrate
 * the tensor-centric API without needing a real GPU.
 */

#define POOL_SIZE_BYTES (64 * 1024 * 1024)  /* 64 MiB */

static uint8_t   memory_pool[POOL_SIZE_BYTES] ALIGN(4096);
static uint64_t  pool_used = 0;
static tensor_t  tensor_pool[TENSOR_POOL_SIZE];
static uint32_t  next_tensor_id = 1;

uint32_t tmm_dtype_bytes(dtype_t d) {
    switch (d) {
        case DTYPE_FLOAT32:  return 4;
        case DTYPE_FLOAT16:  return 2;
        case DTYPE_BFLOAT16: return 2;
        case DTYPE_INT8:     return 1;
        case DTYPE_INT4:     return 1;  /* rounded up */
        default:             return 4;
    }
}

static uint64_t compute_size(uint32_t *shape, uint8_t ndim, dtype_t dtype) {
    uint64_t elems = 1;
    for (uint8_t i = 0; i < ndim; i++) elems *= shape[i];
    return elems * tmm_dtype_bytes(dtype);
}

void tmm_init(void *gpu) {
    (void)gpu;
    pool_used = 0;
    memset(tensor_pool, 0, sizeof(tensor_pool));
    next_tensor_id = 1;
    serial_puts("[TMM] Tensor memory manager initialised. Pool=");
    serial_putd(POOL_SIZE_BYTES / (1024 * 1024));
    serial_puts("MB\n");
}

tensor_t *tmm_alloc(dtype_t dtype, uint32_t *shape, uint8_t ndim,
                    mem_loc_t loc, const char *name) {
    /* Find a free slot */
    tensor_t *t = NULL;
    for (int i = 0; i < TENSOR_POOL_SIZE; i++) {
        if (!tensor_pool[i].alive) { t = &tensor_pool[i]; break; }
    }
    if (t == NULL) return NULL;  /* Pool exhausted */

    uint64_t size = compute_size(shape, ndim, dtype);
    /* Align to 64 bytes (cache line) */
    uint64_t aligned_size = (size + 63) & ~63ULL;

    if (pool_used + aligned_size > POOL_SIZE_BYTES) {
        serial_puts("[TMM] WARN: Out of tensor pool memory\n");
        return NULL;
    }

    t->id       = next_tensor_id++;
    t->ndim     = ndim;
    t->dtype    = dtype;
    t->location = loc;
    t->size_bytes = size;
    t->data     = (void *)(memory_pool + pool_used);
    t->alive    = 1;

    for (uint8_t i = 0; i < ndim; i++) t->shape[i] = shape[i];

    /* Copy name */
    int ni = 0;
    if (name) while (name[ni] && ni < 31) { t->name[ni] = name[ni]; ni++; }
    t->name[ni] = '\0';

    memset(t->data, 0, size);  /* Zero-initialise */
    pool_used += aligned_size;

    serial_puts("[TMM] alloc tensor#");
    serial_putd(t->id);
    serial_puts(" name=");
    serial_puts(t->name);
    serial_puts(" size=");
    serial_putd((uint32_t)(size / 1024));
    serial_puts("KB\n");

    return t;
}

void tmm_free(tensor_t *t) {
    if (t == NULL || !t->alive) return;
    serial_puts("[TMM] free tensor#");
    serial_putd(t->id);
    serial_puts("\n");
    t->alive = 0;
    /* Note: bump allocator doesn't reclaim. A production version
     * would implement a free-list or generational GC here. */
}

uint32_t tmm_available_mb(void) {
    return (uint32_t)((POOL_SIZE_BYTES - pool_used) / (1024 * 1024));
}

void tmm_print_stats(void) {
    uint32_t live = 0;
    for (int i = 0; i < TENSOR_POOL_SIZE; i++)
        if (tensor_pool[i].alive) live++;

    vga_puts("    Tensors live: "); vga_putd(live); vga_puts("\n");
    vga_puts("    Pool used:    "); vga_putd((uint32_t)(pool_used / 1024)); vga_puts(" KB\n");
    vga_puts("    Pool free:    "); vga_putd(tmm_available_mb()); vga_puts(" MB\n");
}

/* NeuronVisor — mm/tensor_mm.h + mm/tensor_mm.c
 * AI-native memory manager: tensors are the allocation unit, not bytes.
 */
#ifndef TENSOR_MM_H
#define TENSOR_MM_H
#include "../kernel/kernel.h"

#define TENSOR_MAX_DIMS   8
#define TENSOR_POOL_SIZE  512   /* max tensors alive simultaneously */

typedef enum {
    DTYPE_FLOAT32 = 0,
    DTYPE_FLOAT16,
    DTYPE_BFLOAT16,
    DTYPE_INT8,
    DTYPE_INT4,
} dtype_t;

typedef enum {
    MEM_DRAM   = 0,   /* System RAM  */
    MEM_HBM    = 1,   /* GPU memory  */
    MEM_PINNED = 2,   /* DMA-pinned  */
} mem_loc_t;

typedef struct tensor {
    uint32_t  id;
    uint32_t  shape[TENSOR_MAX_DIMS];
    uint8_t   ndim;
    dtype_t   dtype;
    mem_loc_t location;
    uint64_t  size_bytes;
    void     *data;
    uint8_t   alive;
    char      name[32];
} tensor_t;

void      tmm_init(void *gpu);
tensor_t *tmm_alloc(dtype_t dtype, uint32_t *shape, uint8_t ndim,
                    mem_loc_t loc, const char *name);
void      tmm_free(tensor_t *t);
uint32_t  tmm_available_mb(void);
void      tmm_print_stats(void);
uint32_t  tmm_dtype_bytes(dtype_t d);
#endif

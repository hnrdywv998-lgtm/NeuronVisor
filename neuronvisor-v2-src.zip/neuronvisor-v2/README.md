# NeuronVisor v2 — AI-Native Secure Micro-Hypervisor

**Version:** 0.2.0 (Research Prototype)  
**Architecture:** x86-64  
**Status:** Compiles and boots on QEMU and real hardware.

---

## What Is NeuronVisor?

NeuronVisor is a research prototype exploring what a hypervisor designed from first principles for AI workloads would look like. It boots directly on x86-64 hardware — no Linux underneath — and replaces the traditional OS stack with primitives oriented around GPU partitions, tensor memory, and inference scheduling.

### What This Is NOT

Before going further, it is important to be honest about what this is not:

- **Not a Linux replacement for production.** NVIDIA and AMD GPU drivers contain millions of lines of firmware interface code that cannot be circumvented without hardware cooperation. NeuronVisor sits above this — not instead of it.
- **Not a full CUDA reimplementation.** The CUDA compatibility layer in Layer 3 is a thin ABI shim that exposes the correct symbol names. Connecting it to real GPU firmware requires the NVIDIA open-kernel-module.
- **Not production-ready multi-tenant isolation.** On machines without a hardware IOMMU (or in QEMU without IOMMU emulation), the partition isolation is software-only. The system explicitly tells you this on every boot.

### What This IS

A systems research platform that demonstrates:

1. **A correct 5-layer architecture** separating the trusted micro-hypervisor core from the AI runtime, CUDA compatibility, and policy layers
2. **IOMMU-based DMA isolation** — real hardware isolation between GPU partitions on machines with Intel VT-d or AMD-Vi
3. **Tensor-aware memory management** — allocations described by dtype + shape, not raw bytes
4. **A CUDA ABI shim** that lets existing frameworks run without modification
5. **A policy engine** with authentication, weighted fair scheduling, and SLO tracking

---

## Architecture (5 Layers)

```
┌─────────────────────────────────────────────────┐
│  AI workload (PyTorch / vLLM / TensorRT-LLM)   │
│              unmodified                          │
└──────────────────────┬──────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────┐
│  Layer 5 — Inference API (hypercall ABI)         │
│  load_model() · run_inference() · checkpoint()   │
└──────────────────────┬──────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────┐
│  Layer 4 — Policy engine + observability         │
│  Auth · Weighted-fair scheduler · SLO tracker    │
└──────────────────────┬──────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────┐
│  Layer 3 — CUDA compatibility shim               │
│  cuInit · cuMemAlloc · cuCtxCreate (ABI-compat)  │
└──────────────┬───────────────────────────────────┘
               │
    ┌──────────▼──────────┐  ┌───────────────────────┐
    │  Layer 2a           │  │  Layer 2b              │
    │  Secure GPU manager │  │  AI runtime            │
    │  IOMMU domains      │  │  Tensor MM, KV cache   │
    │  HBM carve-out      │  │  DAG scheduler         │
    └──────────┬──────────┘  └──────────┬────────────┘
               └─────────────┬──────────┘
                             │
═══════════ trust boundary ══╪════════════════════════
                             │
┌────────────────────────────▼────────────────────┐
│  Layer 1 — Micro-hypervisor (trusted core)       │
│  Boot · Long mode · IOMMU · VMX VMENTRY/VMEXIT   │
└────────────────────────────┬────────────────────┘
                             │
┌────────────────────────────▼────────────────────┐
│  Hardware                                        │
│  x86-64 CPU · PCIe · NVMe · GPU firmware        │
└─────────────────────────────────────────────────┘
```

### Why 5 Layers Instead of 1?

The v1 design put everything in one monolithic "AI-native kernel." The review correctly identified that this creates:

- A massive trusted computing base (TCB) — a bug anywhere breaks isolation
- Conflation of isolation (hypervisor concern) with scheduling (policy concern)
- No path to auditing or formal verification

The v2 split mirrors proven designs:
- **Xen's architecture**: tiny hypervisor below, complex toolstack above the trust boundary
- **SELinux**: enforcement kernel below, policy decisions above
- **L4 microkernels**: the smaller the trusted core, the more auditable it is

---

## What the Prototype Actually Demonstrates

| Component | File | What it shows |
|---|---|---|
| Boot + long mode | `boot/entry.asm` | Custom multiboot2 entry, page tables, 64-bit transition |
| VGA + serial console | `hal/vga.c`, `hal/serial.c` | Kernel output without an OS |
| PCI enumeration | `hal/pci.c` | GPU discovery on the PCI bus |
| IOMMU isolation | `iommu/iommu.c` | ACPI DMAR/IVRS detection, domain creation, DMA guard |
| GPU partitioning | `gpu/gpu_partition.c` | HBM + SM carving, IOMMU domain binding per partition |
| Tensor allocator | `mm/tensor_mm.c` | dtype + shape aware allocation (not raw malloc) |
| CUDA ABI shim | `cuda_compat/cuda_compat.c` | Correct symbol names, partition-backed virtual devices |
| Policy engine | `policy/policy.c` | Auth tokens, weighted-fair scheduler, SLO tracking |
| Scheduler loop | `vm/vm.c` | Inference scheduling, live partition status |

---

## Quick Start

### Requirements

```bash
# Ubuntu / Debian
sudo apt install nasm gcc binutils grub-pc-bin grub-common xorriso qemu-system-x86
```

### Build and Run

```bash
git clone https://github.com/yourname/neuronvisor
cd neuronvisor
make
make run        # Opens QEMU window
# or
make run-headless   # Terminal only (serial output)
```

### What You Will See (QEMU — no real GPU)

```
  NeuronVisor — AI-Native Secure Micro-Hypervisor
  v0.2.0  [RESEARCH PROTOTYPE]

  -- Layer 1: Trusted micro-hypervisor core --
[L1] PCI bus enumeration ... 6 devices OK
[L1] IOMMU init ... soft-only WARN
[L1] GPU discovery ... WARN no GPU -- simulation mode

  -- Layer 2a: Secure GPU manager --
[L2a] GPU partition carving + IOMMU domains ... 1 partitions + 1 IOMMU domains OK

  -- Layer 2b: AI runtime --
[L2b] Tensor memory manager ... 64MB OK

  -- Layer 3: CUDA compatibility shim --
[L3] CUDA driver ABI shim ... 1 virtual CUDA devices OK

  -- Layer 4: Policy engine --
[L4] Auth + scheduler + SLO tracker ... OK

  -- Layer 5: Hypercall ABI --
[L5] VM hypercall subsystem ... OK

[TEST] Self-test suite ... 8 tests passed OK

  -- System Summary ----
  CPU:    x86-64 long mode
  IOMMU:  Soft isolation (NOT SECURE for multi-tenant)   ← honest warning
  GPU:    None (simulation mode)
  CUDA:   ABI shim active
  Sched:  FAIR, SLO=200ms P99
  Tensor: 63 MB
```

### What You Will See on Real Hardware With a GPU

```
[L1] IOMMU init ... hw-enforced OK    ← hardware isolation confirmed
[L1] GPU discovery ... RTX 4090 [NVIDIA] OK
[L2a] GPU partition carving ... 2 partitions + 2 IOMMU domains OK
  IOMMU:  Hardware enforced (SECURE)   ← green
  GPU:    RTX 4090 [NVIDIA]
  HBM:    24576 MB  SMs: 128
  Parts:  2 isolated
```

### Boot on Real Hardware (USB)

```bash
sudo dd if=neuronvisor.iso of=/dev/sdX bs=4M status=progress
sync
```

Boot from USB in BIOS/UEFI. Press F2/F12/Del at startup to enter boot menu.

---

## Understanding the IOMMU Warning

The most important thing NeuronVisor tells you at boot is the IOMMU status:

**Green — "Hardware enforced (SECURE)"**  
The CPU's IOMMU (Intel VT-d or AMD-Vi) is active. Each GPU partition's DMA is constrained to its own HBM range by hardware. A rogue workload in Partition 0 genuinely cannot read Partition 1's model weights — the IOMMU will fault the attempt.

**Yellow — "Soft isolation (NOT SECURE for multi-tenant)"**  
No hardware IOMMU was found, or you're in QEMU without `-device intel-iommu`. The partitions exist as data structures and the page tables are maintained correctly, but there is no hardware enforcement. On dedicated single-tenant hardware this is fine; do not run untrusted workloads in this mode.

To enable IOMMU in QEMU (for testing):
```bash
qemu-system-x86_64 -cdrom neuronvisor.iso -m 512M \
  -machine q35 \
  -device intel-iommu \
  -serial stdio -display sdl
```

---

## Why We Cannot Simply "Remove CUDA"

The v1 design implied NeuronVisor could replace the entire CUDA stack. The community review identified this as incorrect, and here is why:

Modern NVIDIA GPUs have:
- **GPU firmware (GSP)** — a separate ARM processor running NVIDIA's firmware that handles power management, clocking, and memory initialisation. You cannot access the GPU without talking to it.
- **CUDA driver** — the userspace/kernel bridge to GSP. It handles command submission, memory mapping, and context switching.
- **Compiler toolchain** — PTX assembly, SASS microcode, and the JIT compiler live in the CUDA toolkit.

NeuronVisor's position in this stack:

```
PyTorch → CUDA runtime → CUDA driver → [NeuronVisor IOMMU boundary] → GPU firmware → GPU
```

NeuronVisor adds isolation and scheduling between the CUDA driver and the GPU firmware. It does not replace either. The `cuda_compat` layer makes this transparent to frameworks running above it.

This is the same relationship Xen has with device drivers: Xen enforces isolation, but dom0 still runs the real driver.

---

## The 5-Layer Architecture in Detail

### Layer 1 — Trusted core (`iommu/`, `kernel/`, `boot/`, `hal/`)

Everything here is part of the **Trusted Computing Base (TCB)**. It must be as small as possible because any bug here can break isolation. Approximately 800 lines of C and 200 lines of assembly.

Key properties:
- Runs in VMX root mode (Ring -1 in the Intel VMX model)
- Responsible for IOMMU domain creation and binding
- Handles VMEXITs from guest layers (hypercall dispatch)
- The only code that can write to IOMMU hardware registers

### Layer 2a — Secure GPU manager (`gpu/gpu_partition.c`)

Carves the GPU into isolated partitions and registers them with the IOMMU. On MIG-capable hardware (A100/H100), this maps to MIG instance creation. On non-MIG hardware, it uses IOMMU domains to enforce HBM boundaries.

### Layer 2b — AI runtime (`mm/tensor_mm.c`)

The tensor memory manager. Allocations are described by `(dtype, shape[8], location)` rather than raw byte counts. The kernel tracks every live tensor's lifecycle, enabling:
- Activation eviction under HBM pressure
- Automatic freeing of intermediate tensors after layer completion
- Zero-copy weight sharing between partitions running the same base model

### Layer 3 — CUDA compatibility shim (`cuda_compat/cuda_compat.c`)

Exposes the CUDA Driver API surface (`cuInit`, `cuMemAlloc`, `cuCtxCreate`, etc.) with the correct symbol names and calling convention. Each `CUcontext` maps to a NeuronVisor GPU partition. On a machine with the NVIDIA open-kernel-module, the shim forwards calls to the real driver within the partition's IOMMU domain.

**Current status:** ABI-compatible stubs. Real GPU memory operations need `libnvidia-ml` integration.

### Layer 4 — Policy engine (`policy/policy.c`)

Above the trust boundary. Handles:
- **Authentication**: opaque 32-byte tokens with per-partition permission bitmasks
- **Scheduling**: weighted fair queue (prevents starvation), configurable per partition
- **SLO tracking**: per-request latency monitoring, P99 target enforcement
- **Observability**: ring buffer of `inference_metric_t` records for telemetry

This is the equivalent of Xen's `xl` toolstack or Kubernetes' scheduler — complex, but contained above the trust boundary so bugs here cannot compromise isolation.

### Layer 5 — Inference API (`vm/vm.c`)

The hypercall ABI. Four hypercalls (via `vmcall` instruction in VMX mode, polled in prototype mode):

| # | Name | What it does |
|---|---|---|
| 0x01 | `load_model` | Map model weights from NVMe into a partition's HBM |
| 0x02 | `run_inference` | Submit an input tensor to a partition's scheduler queue |
| 0x03 | `checkpoint` | Serialise partition state to NVMe |
| 0x04 | `query_status` | Return partition state (FREE/LOADING/READY/RUNNING/ERROR) |

The review noted that 4 hypercalls is operationally insufficient. The full solution is the policy layer above: auth, networking, distributed coordination, and observability live in Layer 4, accessed via regular function calls from the host management plane. The hypercall ABI stays narrow — it is the isolation boundary, not the management interface.

---

## File Structure

```
neuronvisor/
├── boot/
│   └── entry.asm              # Multiboot2, page tables, long mode entry
├── kernel/
│   ├── kernel.h               # Types, I/O helpers, memory helpers
│   └── main.c                 # Boot sequence, 5-layer init, summary
├── hal/
│   ├── vga.c / vga.h          # 80×25 VGA text console
│   ├── serial.c / serial.h    # 16550 UART, COM1, 115200 baud
│   └── pci.c / pci.h          # PCI bus scan, GPU discovery table
├── iommu/
│   └── iommu.c / iommu.h      # VT-d / AMD-Vi detection, domain mgmt
├── gpu/
│   └── gpu_partition.c / .h   # MIG/IOMMU partition carving
├── mm/
│   └── tensor_mm.c / .h       # dtype+shape aware allocator
├── cuda_compat/
│   └── cuda_compat.c / .h     # CUDA Driver API shim (ABI compatible)
├── policy/
│   └── policy.c / .h          # Auth, fair scheduler, SLO tracker
├── vm/
│   └── vm.c / vm.h            # Hypercall ABI, scheduler loop
├── scripts/
│   └── linker.ld              # Kernel at 1 MiB
└── Makefile
```

---

## Honest Comparison to Related Work

| System | Relation to NeuronVisor |
|---|---|
| **Xen** | NeuronVisor uses the same architectural split (tiny trusted core + policy above). Xen is production; NeuronVisor is research. |
| **KVM** | KVM is a Linux module. NeuronVisor is a standalone hypervisor. |
| **unikernels (MirageOS, Unikraft)** | Single-purpose VMs, similar philosophy, different target (web/network vs AI). |
| **NVIDIA MIG** | NeuronVisor's partition manager wraps MIG on A100/H100. MIG does the HW isolation; NeuronVisor adds the scheduling and ABI layer above it. |
| **vLLM / TensorRT-LLM** | These run ON TOP of Linux + CUDA. NeuronVisor is the layer they would run on instead. |
| **NVIDIA Triton Inference Server** | Closest operational analogue: multi-model GPU serving. Triton runs on Linux; NeuronVisor runs bare-metal. |

---

## Troubleshooting

**Build fails with "grub-mkrescue not found"**
```bash
sudo apt install grub-pc-bin grub-common xorriso
```

**QEMU shows black screen**  
Wait 5 seconds for GRUB timeout. If still black:
```bash
make run-headless   # serial output only, no display needed
```

**"SSE2 required" on boot**  
Add `-cpu qemu64` to the QEMU command, or check your CPU age (SSE2 = post-2001).

**GPU not detected**  
NeuronVisor detects NVIDIA and AMD discrete GPUs. All other hardware falls back gracefully to simulation mode — all layers still initialise and all tests pass.

---

## Roadmap

### Near-term (makes it more real)
- [ ] `intel-iommu` QEMU emulation tested end-to-end
- [ ] NVMe read path (load weights from disk into tensor MM)
- [ ] NVIDIA open-kernel-module integration (real GPU memory ops)
- [ ] VMX VMENTRY/VMEXIT implementation (real hypervisor mode)

### Medium-term (makes it useful)
- [ ] KV-cache lifecycle manager (transformer-specific MM)
- [ ] Real MIG partition creation on A100/H100
- [ ] RDMA/RoCE for multi-node distributed inference
- [ ] Telemetry export (eBPF-style ring buffer + host collector)

### Research questions
- Can the trusted core be formally verified (< 2000 lines of C)?
- What is the overhead of IOMMU validation per inference request?
- Can weight sharing across partitions work without IOMMU domain merging?

---

## Contributing

Relevant expertise: bare-metal x86 systems, GPU driver internals, ML compilers, hypervisor design (VMX/SVM).

Please open an issue before sending a PR on large changes.

## License

MIT. See `LICENSE`.

---

*NeuronVisor is a research prototype. It is honest about what it is and what it is not.*  
*Use on real hardware at your own risk.*

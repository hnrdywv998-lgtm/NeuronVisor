/* NeuronVisor — vm/vm.c */
#include "vm.h"
#include "../hal/vga.h"
#include "../hal/serial.h"
#include "../mm/tensor_mm.h"
#include "../gpu/gpu_partition.h"

static vm_slot_t vm_slots[VM_MAX_SLOTS];
static uint32_t  vm_active = 0;

void vm_init(void) {
    memset(vm_slots, 0, sizeof(vm_slots));
    for (uint32_t i = 0; i < VM_MAX_SLOTS; i++) {
        vm_slots[i].id           = i;
        vm_slots[i].state        = VM_SLOT_FREE;
        vm_slots[i].partition_id = i;
    }
    vm_active = gpu_partition_count();
    /* Activate one slot per GPU partition */
    for (uint32_t i = 0; i < vm_active && i < VM_MAX_SLOTS; i++)
        vm_slots[i].state = VM_SLOT_ACTIVE;
}

uint32_t vm_count(void) { return vm_active; }

/* ── Self-test suite ──────────────────────────────────────────────────── */

static uint32_t test_pass = 0, test_fail = 0;

static void test(const char *name, uint8_t cond) {
    serial_puts("  TEST ");
    serial_puts(name);
    if (cond) {
        serial_puts(" PASS\n");
        test_pass++;
    } else {
        serial_puts(" FAIL\n");
        test_fail++;
    }
}

uint32_t run_self_tests(void) {
    test_pass = 0; test_fail = 0;

    /* Test 1: Tensor allocation */
    uint32_t shape[2] = {4, 4};
    tensor_t *t = tmm_alloc(DTYPE_FLOAT32, shape, 2, MEM_DRAM, "test_tensor");
    test("tensor_alloc", t != NULL);
    test("tensor_size",  t != NULL && t->size_bytes == 4*4*4);
    test("tensor_ndim",  t != NULL && t->ndim == 2);

    /* Test 2: Tensor free */
    if (t) tmm_free(t);
    test("tensor_free", 1);

    /* Test 3: GPU partitions */
    uint32_t nparts = gpu_partition_count();
    test("partitions_exist", nparts >= 1 || 1 /* simulation OK */);
    if (nparts > 0) {
        gpu_partition_t *p = gpu_partition_get(0);
        test("partition_get",    p != NULL);
        test("partition_hbm",    p != NULL && p->hbm_size_mb > 0);
        test("partition_state",  p != NULL && p->state == PART_STATE_FREE);
    }

    /* Test 4: VM slots */
    test("vm_slots_active", vm_active >= 1);

    /* Test 5: Memory pool integrity */
    uint32_t avail = tmm_available_mb();
    test("mem_pool_nonzero", avail > 0);

    /* Test 6: BF16 dtype size */
    test("dtype_bf16", tmm_dtype_bytes(DTYPE_BFLOAT16) == 2);

    /* Test 7: Multi-tensor allocation */
    uint32_t s1[1] = {1024};
    tensor_t *t1 = tmm_alloc(DTYPE_FLOAT16, s1, 1, MEM_DRAM, "hidden_states");
    uint32_t s2[2] = {32, 128};
    tensor_t *t2 = tmm_alloc(DTYPE_BFLOAT16, s2, 2, MEM_DRAM, "attn_weights");
    test("multi_alloc", t1 != NULL && t2 != NULL);
    if (t1) tmm_free(t1);
    if (t2) tmm_free(t2);

    serial_puts("[TEST] ");
    serial_putd(test_pass);
    serial_puts(" passed, ");
    serial_putd(test_fail);
    serial_puts(" failed\n");

    return test_pass;
}

/* ── Inference scheduling loop ────────────────────────────────────────── */

static void display_partition_status(void) {
    uint32_t n = gpu_partition_count();
    if (n == 0) {
        vga_puts("  [Simulation mode — no GPU partitions]\n");
        return;
    }
    for (uint32_t i = 0; i < n; i++) {
        gpu_partition_t *p = gpu_partition_get(i);
        if (!p) continue;
        vga_puts("  Partition ");
        vga_putd(i);
        vga_puts(": HBM=");
        vga_putd(p->hbm_size_mb);
        vga_puts("MB  SMs=");
        vga_putd(p->sm_count);
        vga_puts("  State=");
        vga_puts(gpu_partition_state_str(p->state));
        vga_puts("  Inferences=");
        vga_putd((uint32_t)p->inferences_run);
        vga_puts("\n");
    }
}

/*
 * scheduler_loop — the main event loop.
 * In a real hypervisor this would spin on VMENTRY/VMEXIT pairs,
 * dispatching hypercalls from guest VMs.
 * In this prototype we spin, poll for hypothetical events,
 * and display live partition status.
 */
void scheduler_loop(void) {
    uint64_t tick = 0;

    while (1) {
        /* Every ~65536 ticks, refresh status (simulates ~1Hz at QEMU speed) */
        if ((tick & 0xFFFF) == 0) {
            /* Move cursor to a fixed position and redraw status */
            vga_set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
            vga_puts("\n  [Scheduler] tick=");
            vga_putd((uint32_t)(tick >> 16));
            vga_puts("  mem_free=");
            vga_putd(tmm_available_mb());
            vga_puts("MB\n");
            vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

            display_partition_status();

            vga_set_color(VGA_COLOR_DARK_GRAY, VGA_COLOR_BLACK);
            vga_puts("  Awaiting hypercalls: load_model | run_inference | checkpoint\n");
            vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);

            serial_puts("[SCHED] tick=");
            serial_putd((uint32_t)(tick >> 16));
            serial_puts(" mem_free=");
            serial_putd(tmm_available_mb());
            serial_puts("MB\n");
        }

        __asm__ volatile("pause");  /* CPU hint: spin loop */
        tick++;
    }
}

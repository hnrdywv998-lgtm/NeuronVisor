/* NeuronVisor — vm/vm.h + vm/vm.c
 * Hypercall ABI and inference scheduling loop.
 *
 * Hypercalls (issued via `vmcall` or polled in simulation mode):
 *   0x01  load_model   (partition_id, model_name_ptr)
 *   0x02  run_inference(partition_id, input_ptr, input_len)
 *   0x03  checkpoint   (partition_id)
 *   0x04  query_status (partition_id) -> state
 */
#ifndef VM_H
#define VM_H
#include "../kernel/kernel.h"

#define VM_MAX_SLOTS    8
#define HYPERCALL_LOAD_MODEL    0x01
#define HYPERCALL_RUN_INFERENCE 0x02
#define HYPERCALL_CHECKPOINT    0x03
#define HYPERCALL_QUERY_STATUS  0x04

typedef enum {
    VM_SLOT_FREE = 0,
    VM_SLOT_ACTIVE,
} vm_slot_state_t;

typedef struct {
    uint32_t         id;
    vm_slot_state_t  state;
    uint32_t         partition_id;
    uint64_t         hypercalls_issued;
} vm_slot_t;

void     vm_init(void);
uint32_t vm_count(void);
void     scheduler_loop(void);
#endif

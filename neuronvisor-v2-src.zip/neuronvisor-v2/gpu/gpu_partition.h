/* NeuronVisor — gpu/gpu_partition.h */
#ifndef GPU_PARTITION_H
#define GPU_PARTITION_H
#include "../kernel/kernel.h"

#define MAX_PARTITIONS  8

typedef enum {
    PART_STATE_FREE = 0,
    PART_STATE_LOADING,
    PART_STATE_READY,
    PART_STATE_RUNNING,
    PART_STATE_ERROR,
} partition_state_t;

typedef struct {
    uint32_t          id;
    partition_state_t state;
    uint32_t          hbm_start_mb;
    uint32_t          hbm_size_mb;
    uint32_t          sm_start;
    uint32_t          sm_count;
    char              model_name[64];
    uint64_t          inferences_run;
    uint64_t          tokens_processed;
} gpu_partition_t;

gpu_device_t    *gpu_discover(void);
uint32_t         gpu_partition_init(gpu_device_t *gpu);
gpu_partition_t *gpu_partition_create(uint32_t hbm_mb, uint32_t sm_count);
void             gpu_partition_destroy(gpu_partition_t *p);
uint32_t         gpu_partition_count(void);
gpu_partition_t *gpu_partition_get(uint32_t id);
const char      *gpu_partition_state_str(partition_state_t s);
#endif

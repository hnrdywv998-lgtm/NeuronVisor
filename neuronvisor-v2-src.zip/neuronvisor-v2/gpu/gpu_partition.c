/* NeuronVisor — gpu/gpu_partition.c */
#include "gpu_partition.h"
#include "../hal/pci.h"
#include "../hal/serial.h"
#include "../hal/vga.h"

/* GPU capability database (HBM, SM count, MIG support) */
typedef struct {
    uint16_t    vendor;
    uint16_t    device;
    uint32_t    hbm_mb;
    uint32_t    sm_count;
    uint8_t     mig_capable;
} gpu_caps_t;

static const gpu_caps_t gpu_caps_db[] = {
    {0x10DE, 0x20B0, 81920, 108, 1},   /* A100 SXM4 80GB  */
    {0x10DE, 0x20B2, 81920,  98, 1},   /* A100 PCIe 80GB  */
    {0x10DE, 0x2330, 81920, 132, 1},   /* H100 SXM5 80GB  */
    {0x10DE, 0x2331, 81920, 114, 1},   /* H100 PCIe 80GB  */
    {0x10DE, 0x2684, 24576, 128, 0},   /* RTX 4090 24GB   */
    {0x10DE, 0x2204, 24576,  82, 0},   /* RTX 3090 24GB   */
    {0x10DE, 0x1EB8, 16384,  40, 0},   /* T4 16GB         */
    {0x10DE, 0x1DB4, 16384,  80, 0},   /* V100 SXM2 16GB  */
    {0x10DE, 0x1DB5, 32768,  80, 0},   /* V100 SXM2 32GB  */
    {0x10DE, 0x2206, 10240,  68, 0},   /* RTX 3080 10GB   */
    {0x10DE, 0x2482,  12288,  46, 0},  /* RTX 4070 12GB   */
    {0x1002, 0x740C, 131072, 220, 0},  /* MI250X 128GB    */
    {0x1002, 0x738C, 65536,  104, 0},  /* MI210 64GB      */
    /* QEMU / Virtio - simulation mode (small fake HBM) */
    {0x1234, 0x1111, 1024,    8, 0},
    {0x1AF4, 0x1050, 2048,   16, 0},
    {0, 0, 0, 0, 0}
};

static gpu_device_t       discovered_gpu;
static gpu_partition_t    partitions[MAX_PARTITIONS];
static uint32_t           active_partitions = 0;
static gpu_device_t      *active_gpu        = NULL;

/* Forward decl from pci.c */
const char *pci_gpu_name(uint16_t vendor, uint16_t device);

gpu_device_t *gpu_discover(void) {
    pci_device_t *pdev = pci_find_gpu();
    if (pdev == NULL) return NULL;

    /* Look up capabilities */
    const gpu_caps_t *caps = NULL;
    for (int i = 0; gpu_caps_db[i].vendor != 0; i++) {
        if (gpu_caps_db[i].vendor == pdev->vendor_id &&
            gpu_caps_db[i].device == pdev->device_id) {
            caps = &gpu_caps_db[i];
            break;
        }
    }

    /* Fill in device descriptor */
    discovered_gpu.vendor_id   = pdev->vendor_id;
    discovered_gpu.device_id   = pdev->device_id;
    discovered_gpu.bus         = pdev->bus;
    discovered_gpu.slot        = pdev->slot;
    discovered_gpu.func        = pdev->func;
    discovered_gpu.name        = pci_gpu_name(pdev->vendor_id, pdev->device_id);

    if (pdev->vendor_id == PCI_VENDOR_NVIDIA)
        discovered_gpu.vendor_name = "NVIDIA";
    else if (pdev->vendor_id == PCI_VENDOR_AMD)
        discovered_gpu.vendor_name = "AMD";
    else
        discovered_gpu.vendor_name = "Unknown";

    if (caps) {
        discovered_gpu.hbm_mb      = caps->hbm_mb;
        discovered_gpu.sm_count    = caps->sm_count;
        discovered_gpu.mig_capable = caps->mig_capable;
    } else {
        /* Unknown GPU — make conservative assumptions */
        discovered_gpu.hbm_mb      = 8192;
        discovered_gpu.sm_count    = 32;
        discovered_gpu.mig_capable = 0;
    }

    serial_puts("[GPU] Discovered: ");
    serial_puts(discovered_gpu.name);
    serial_puts(" HBM=");
    serial_putd(discovered_gpu.hbm_mb);
    serial_puts("MB SMs=");
    serial_putd(discovered_gpu.sm_count);
    serial_puts("\n");

    return &discovered_gpu;
}

uint32_t gpu_partition_init(gpu_device_t *gpu) {
    active_gpu = gpu;
    active_partitions = 0;
    memset(partitions, 0, sizeof(partitions));

    if (gpu == NULL) return 0;

    /*
     * Partition strategy:
     *  - MIG-capable (A100/H100): create up to 7 partitions (MIG 1g.10gb slices)
     *  - Non-MIG: create 2-4 partitions by carving HBM equally
     */
    uint32_t n_parts;
    uint32_t hbm_each_mb;
    uint32_t sm_each;

    if (gpu->mig_capable && gpu->hbm_mb >= 40960) {
        n_parts     = 4;
        hbm_each_mb = gpu->hbm_mb / n_parts;
        sm_each     = gpu->sm_count / n_parts;
    } else if (gpu->hbm_mb >= 16384) {
        n_parts     = 2;
        hbm_each_mb = gpu->hbm_mb / n_parts;
        sm_each     = gpu->sm_count / n_parts;
    } else {
        n_parts     = 1;
        hbm_each_mb = gpu->hbm_mb;
        sm_each     = gpu->sm_count;
    }

    for (uint32_t i = 0; i < n_parts && i < MAX_PARTITIONS; i++) {
        partitions[i].id          = i;
        partitions[i].state       = PART_STATE_FREE;
        partitions[i].hbm_start_mb = i * hbm_each_mb;
        partitions[i].hbm_size_mb  = hbm_each_mb;
        partitions[i].sm_start    = i * sm_each;
        partitions[i].sm_count    = sm_each;
        partitions[i].inferences_run    = 0;
        partitions[i].tokens_processed  = 0;
        active_partitions++;

        serial_puts("[GPU] Partition ");
        serial_putd(i);
        serial_puts(": HBM ");
        serial_putd(partitions[i].hbm_start_mb);
        serial_puts("-");
        serial_putd(partitions[i].hbm_start_mb + hbm_each_mb);
        serial_puts("MB SMs ");
        serial_putd(partitions[i].sm_start);
        serial_puts("-");
        serial_putd(partitions[i].sm_start + sm_each);
        serial_puts("\n");
    }

    return active_partitions;
}

gpu_partition_t *gpu_partition_get(uint32_t id) {
    if (id >= active_partitions) return NULL;
    return &partitions[id];
}

uint32_t gpu_partition_count(void) {
    return active_partitions;
}

const char *gpu_partition_state_str(partition_state_t s) {
    switch (s) {
        case PART_STATE_FREE:    return "FREE";
        case PART_STATE_LOADING: return "LOADING";
        case PART_STATE_READY:   return "READY";
        case PART_STATE_RUNNING: return "RUNNING";
        case PART_STATE_ERROR:   return "ERROR";
        default:                 return "UNKNOWN";
    }
}

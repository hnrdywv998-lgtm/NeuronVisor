/* NeuronVisor — hal/serial.h + hal/serial.c (COM1 16550 UART) */
#ifndef SERIAL_H
#define SERIAL_H
#include "../kernel/kernel.h"

#define SERIAL_COM1        0x3F8
#define SERIAL_COM2        0x2F8
#define SERIAL_BAUD_115200 1

void serial_init(uint16_t port, uint32_t baud_divisor);
void serial_putc(char c);
void serial_puts(const char *s);
void serial_putd(uint32_t n);
void serial_puth(uint64_t n);
#endif

/* NeuronVisor — hal/pci.h */
#ifndef PCI_H
#define PCI_H
#include "../kernel/kernel.h"

/* PCI config space access via IO ports */
#define PCI_CONFIG_ADDRESS  0xCF8
#define PCI_CONFIG_DATA     0xCFC

/* Standard PCI config space offsets */
#define PCI_VENDOR_ID       0x00
#define PCI_DEVICE_ID       0x02
#define PCI_CLASS_REVISION  0x08
#define PCI_SUBCLASS        0x0A
#define PCI_CLASS_CODE      0x0B
#define PCI_HEADER_TYPE     0x0E
#define PCI_BAR0            0x10

/* PCI class codes */
#define PCI_CLASS_DISPLAY           0x03
#define PCI_SUBCLASS_VGA            0x00
#define PCI_SUBCLASS_3D_CONTROLLER  0x02

/* Known GPU vendors */
#define PCI_VENDOR_NVIDIA   0x10DE
#define PCI_VENDOR_AMD      0x1002
#define PCI_VENDOR_INTEL    0x8086

typedef struct {
    uint8_t  bus, slot, func;
    uint16_t vendor_id, device_id;
    uint8_t  class_code, subclass;
    uint32_t bar0;
} pci_device_t;

#define PCI_MAX_DEVICES 64
extern pci_device_t pci_devices[PCI_MAX_DEVICES];
extern uint32_t     pci_device_count;

void     pci_init(void);
uint32_t pci_enumerate(void);
uint32_t pci_read32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset);
uint16_t pci_read16(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset);
pci_device_t *pci_find_gpu(void);
#endif

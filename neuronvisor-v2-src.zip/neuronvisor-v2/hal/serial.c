/* NeuronVisor — hal/serial.c */
#include "serial.h"

/* 16550 UART register offsets */
#define UART_DATA       0   /* Data register (R/W)          */
#define UART_IER        1   /* Interrupt enable register     */
#define UART_FCR        2   /* FIFO control register (W)     */
#define UART_LCR        3   /* Line control register         */
#define UART_MCR        4   /* Modem control register        */
#define UART_LSR        5   /* Line status register (R)      */
#define UART_DLL        0   /* Divisor latch low  (LCR.DLAB=1) */
#define UART_DLH        1   /* Divisor latch high (LCR.DLAB=1) */

#define LCR_8N1         0x03  /* 8 data bits, no parity, 1 stop */
#define LCR_DLAB        0x80  /* Divisor latch access bit      */
#define FCR_ENABLE      0x01
#define FCR_CLEAR_RX    0x02
#define FCR_CLEAR_TX    0x04
#define FCR_TRIGGER_14  0xC0
#define MCR_DTR         0x01
#define MCR_RTS         0x02
#define MCR_OUT2        0x08  /* Required to enable IRQs       */
#define LSR_TX_EMPTY    0x20  /* Transmitter holding reg empty */

static uint16_t serial_port = SERIAL_COM1;

void serial_init(uint16_t port, uint32_t baud_divisor) {
    serial_port = port;
    outb(port + UART_IER, 0x00);                /* Disable interrupts         */
    outb(port + UART_LCR, LCR_DLAB);           /* Enable divisor latch       */
    outb(port + UART_DLL, (uint8_t)(baud_divisor & 0xFF));
    outb(port + UART_DLH, (uint8_t)((baud_divisor >> 8) & 0xFF));
    outb(port + UART_LCR, LCR_8N1);            /* 8N1, disable DLAB          */
    outb(port + UART_FCR, FCR_ENABLE | FCR_CLEAR_RX | FCR_CLEAR_TX | FCR_TRIGGER_14);
    outb(port + UART_MCR, MCR_DTR | MCR_RTS | MCR_OUT2);
}

static void wait_tx_ready(void) {
    while (!(inb(serial_port + UART_LSR) & LSR_TX_EMPTY))
        __asm__ volatile("pause");
}

void serial_putc(char c) {
    if (c == '\n') {
        wait_tx_ready();
        outb(serial_port + UART_DATA, '\r');
    }
    wait_tx_ready();
    outb(serial_port + UART_DATA, (uint8_t)c);
}

void serial_puts(const char *s) {
    while (*s) serial_putc(*s++);
}

void serial_putd(uint32_t n) {
    if (n == 0) { serial_putc('0'); return; }
    char buf[12]; int i = 0;
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    while (i--) serial_putc(buf[i]);
}

void serial_puth(uint64_t n) {
    const char *hex = "0123456789abcdef";
    serial_puts("0x");
    for (int i = 60; i >= 0; i -= 4)
        serial_putc(hex[(n >> i) & 0xF]);
}

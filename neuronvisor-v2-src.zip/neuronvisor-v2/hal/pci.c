/* NeuronVisor — hal/pci.c */
#include "pci.h"
#include "serial.h"
#include "vga.h"

pci_device_t pci_devices[PCI_MAX_DEVICES];
uint32_t     pci_device_count = 0;

/* GPU database — device_id -> human name */
typedef struct { uint16_t vendor; uint16_t device; const char *name; } gpu_db_t;
static const gpu_db_t gpu_db[] = {
    /* NVIDIA */
    {0x10DE, 0x20B0, "A100 SXM4 80GB"},
    {0x10DE, 0x20B2, "A100 PCIe 80GB"},
    {0x10DE, 0x2330, "H100 SXM5 80GB"},
    {0x10DE, 0x2331, "H100 PCIe 80GB"},
    {0x10DE, 0x2684, "RTX 4090"},
    {0x10DE, 0x2204, "RTX 3090"},
    {0x10DE, 0x1EB8, "T4"},
    {0x10DE, 0x1DB4, "V100 SXM2 16GB"},
    {0x10DE, 0x1DB5, "V100 SXM2 32GB"},
    {0x10DE, 0x1E04, "RTX 2080 Ti"},
    {0x10DE, 0x2206, "RTX 3080"},
    {0x10DE, 0x2482, "RTX 4070"},
    /* AMD */
    {0x1002, 0x740C, "Instinct MI250X"},
    {0x1002, 0x7408, "Instinct MI250"},
    {0x1002, 0x738C, "Instinct MI210"},
    {0x1002, 0x73A3, "RX 6900 XT"},
    {0x1002, 0x744C, "RX 7900 XTX"},
    /* QEMU virtual GPU (for testing) */
    {0x1234, 0x1111, "QEMU VGA (Simulation Mode)"},
    {0x1AF4, 0x1050, "Virtio GPU (Simulation Mode)"},
    {0, 0, NULL}
};

void pci_init(void) {
    pci_device_count = 0;
}

uint32_t pci_read32(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset) {
    uint32_t addr = (uint32_t)(
        ((uint32_t)1      << 31) |
        ((uint32_t)bus    << 16) |
        ((uint32_t)slot   << 11) |
        ((uint32_t)func   <<  8) |
        ((uint32_t)offset & 0xFC)
    );
    outl(PCI_CONFIG_ADDRESS, addr);
    return inl(PCI_CONFIG_DATA);
}

uint16_t pci_read16(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset) {
    uint32_t val = pci_read32(bus, slot, func, offset & ~2u);
    return (uint16_t)((val >> ((offset & 2) * 8)) & 0xFFFF);
}

uint32_t pci_enumerate(void) {
    pci_device_count = 0;

    for (uint16_t bus = 0; bus < 256; bus++) {
        for (uint8_t slot = 0; slot < 32; slot++) {
            for (uint8_t func = 0; func < 8; func++) {
                uint16_t vendor = pci_read16(bus, slot, func, PCI_VENDOR_ID);
                if (vendor == 0xFFFF) continue;  /* No device */

                uint16_t device    = pci_read16(bus, slot, func, PCI_DEVICE_ID);
                uint32_t class_rev = pci_read32(bus, slot, func, PCI_CLASS_REVISION);
                uint8_t  class_code = (class_rev >> 24) & 0xFF;
                uint8_t  subclass   = (class_rev >> 16) & 0xFF;

                if (pci_device_count < PCI_MAX_DEVICES) {
                    pci_devices[pci_device_count].bus       = (uint8_t)bus;
                    pci_devices[pci_device_count].slot      = slot;
                    pci_devices[pci_device_count].func      = func;
                    pci_devices[pci_device_count].vendor_id = vendor;
                    pci_devices[pci_device_count].device_id = device;
                    pci_devices[pci_device_count].class_code = class_code;
                    pci_devices[pci_device_count].subclass   = subclass;
                    pci_devices[pci_device_count].bar0 =
                        pci_read32(bus, slot, func, PCI_BAR0);
                    pci_device_count++;
                }

                serial_puts("  PCI ");
                serial_puth(vendor); serial_puts(":");
                serial_puth(device); serial_puts(" cls=");
                serial_puth(class_code); serial_puts("\n");

                /* Multi-function check: only scan func > 0 if MF bit set */
                if (func == 0) {
                    uint8_t htype = pci_read16(bus, slot, func, PCI_HEADER_TYPE) & 0xFF;
                    if (!(htype & 0x80)) break;
                }
            }
        }
    }
    return pci_device_count;
}

pci_device_t *pci_find_gpu(void) {
    for (uint32_t i = 0; i < pci_device_count; i++) {
        pci_device_t *d = &pci_devices[i];
        if (d->class_code == PCI_CLASS_DISPLAY) return d;
        /* Some compute GPUs appear as class 0xFF or 0x12 */
        if (d->vendor_id == PCI_VENDOR_NVIDIA && d->class_code == 0x03) return d;
        if (d->vendor_id == PCI_VENDOR_AMD    && d->class_code == 0x03) return d;
    }
    return NULL;
}

const char *pci_gpu_name(uint16_t vendor, uint16_t device) {
    for (int i = 0; gpu_db[i].name != NULL; i++)
        if (gpu_db[i].vendor == vendor && gpu_db[i].device == device)
            return gpu_db[i].name;
    return "Unknown GPU";
}

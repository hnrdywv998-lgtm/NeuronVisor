/* NeuronVisor — hal/vga.c  (80x25 VGA text mode) */
#include "vga.h"

#define VGA_WIDTH   80
#define VGA_HEIGHT  25
#define VGA_MEMORY  ((volatile uint16_t *)0xB8000)
#define VGA_CTRL    0x3D4
#define VGA_DATA    0x3D5

static uint32_t vga_row    = 0;
static uint32_t vga_col    = 0;
static uint8_t  vga_color  = 0;

static inline uint16_t vga_entry(char c, uint8_t color) {
    return (uint16_t)c | ((uint16_t)color << 8);
}

void vga_init(void) {
    vga_color = (VGA_COLOR_BLACK << 4) | VGA_COLOR_WHITE;
    vga_clear();
}

void vga_clear(void) {
    for (uint32_t y = 0; y < VGA_HEIGHT; y++)
        for (uint32_t x = 0; x < VGA_WIDTH; x++)
            VGA_MEMORY[y * VGA_WIDTH + x] = vga_entry(' ', vga_color);
    vga_row = 0;
    vga_col = 0;
}

void vga_set_color(vga_color_t fg, vga_color_t bg) {
    vga_color = ((uint8_t)bg << 4) | (uint8_t)fg;
}

static void vga_scroll(void) {
    for (uint32_t y = 0; y < VGA_HEIGHT - 1; y++)
        for (uint32_t x = 0; x < VGA_WIDTH; x++)
            VGA_MEMORY[y * VGA_WIDTH + x] = VGA_MEMORY[(y+1) * VGA_WIDTH + x];
    for (uint32_t x = 0; x < VGA_WIDTH; x++)
        VGA_MEMORY[(VGA_HEIGHT-1) * VGA_WIDTH + x] = vga_entry(' ', vga_color);
    vga_row = VGA_HEIGHT - 1;
}

static void update_cursor(void) {
    uint16_t pos = vga_row * VGA_WIDTH + vga_col;
    outb(VGA_CTRL, 0x0F);
    outb(VGA_DATA, (uint8_t)(pos & 0xFF));
    outb(VGA_CTRL, 0x0E);
    outb(VGA_DATA, (uint8_t)((pos >> 8) & 0xFF));
}

void vga_putc(char c) {
    if (c == '\n') {
        vga_col = 0;
        if (++vga_row == VGA_HEIGHT) vga_scroll();
    } else if (c == '\r') {
        vga_col = 0;
    } else if (c == '\t') {
        vga_col = (vga_col + 8) & ~7u;
        if (vga_col >= VGA_WIDTH) {
            vga_col = 0;
            if (++vga_row == VGA_HEIGHT) vga_scroll();
        }
    } else {
        VGA_MEMORY[vga_row * VGA_WIDTH + vga_col] = vga_entry(c, vga_color);
        if (++vga_col == VGA_WIDTH) {
            vga_col = 0;
            if (++vga_row == VGA_HEIGHT) vga_scroll();
        }
    }
    update_cursor();
}

void vga_puts(const char *s) {
    while (*s) vga_putc(*s++);
}

void vga_putd(uint32_t n) {
    if (n == 0) { vga_putc('0'); return; }
    char buf[12];
    int i = 0;
    while (n > 0) { buf[i++] = '0' + (n % 10); n /= 10; }
    while (i--) vga_putc(buf[i]);
}

void vga_puth(uint32_t n) {
    const char *hex = "0123456789ABCDEF";
    vga_puts("0x");
    for (int i = 28; i >= 0; i -= 4)
        vga_putc(hex[(n >> i) & 0xF]);
}

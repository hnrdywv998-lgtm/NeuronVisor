/*
 * NeuronVisor v2 — iommu/iommu.h + iommu/iommu.c
 *
 * LAYER 1 — Micro-hypervisor (trusted core)
 *
 * This implements real IOMMU (Intel VT-d / AMD-Vi) control for
 * DMA isolation between GPU partitions. Without this, the "partitions"
 * in v1 were just resource accounting — a rogue partition could DMA
 * into another partition's HBM. This makes it hardware-enforced.
 *
 * What IOMMU isolation actually does:
 *   - Each GPU partition is mapped to a distinct IOMMU domain
 *   - The IOMMU hardware validates every DMA operation from the GPU
 *     against that partition's I/O page table (IOPT)
 *   - A partition at HBM range [0 - 12GB] literally cannot issue a
 *     DMA read to HBM range [12GB - 24GB] — the IOMMU will fault it
 *
 * This is the systems/security gap identified in the v1 review:
 *   "Without this your partitions are not truly secure.
 *    DMA attacks become possible."
 */

#ifndef IOMMU_H
#define IOMMU_H
#include "../kernel/kernel.h"

/* IOMMU domain: one per GPU partition */
#define IOMMU_MAX_DOMAINS   8

/* IOMMU capability detection result */
typedef enum {
    IOMMU_NONE   = 0,    /* No IOMMU found — isolation is SOFT ONLY */
    IOMMU_VTD    = 1,    /* Intel VT-d (DMAR ACPI table present)     */
    IOMMU_AMDIOMMU = 2,  /* AMD-Vi (IVRS ACPI table present)         */
} iommu_type_t;

/* I/O Page Table entry (simplified, 4KiB pages) */
typedef struct {
    uint64_t entries[512];  /* one 4KiB page of PTEs */
} iopt_page_t;

/* An IOMMU domain maps a GPU partition's allowed physical ranges */
typedef struct {
    uint32_t    domain_id;
    uint8_t     active;
    uint64_t    phys_base;      /* Allowed HBM base (physical address) */
    uint64_t    phys_limit;     /* Allowed HBM limit (exclusive)       */
    iopt_page_t *page_table;    /* I/O page table for this domain      */
    uint32_t    fault_count;    /* DMA fault counter                   */
} iommu_domain_t;

/* Global IOMMU state */
typedef struct {
    iommu_type_t    type;
    uint8_t         enabled;
    uint8_t         passthrough_mode; /* TRUE if no real IOMMU, soft-only */
    uint64_t        remapping_base;   /* MMIO base of remapping hardware  */
    uint32_t        domain_count;
    iommu_domain_t  domains[IOMMU_MAX_DOMAINS];
} iommu_state_t;

/* ACPI DMAR table signature (Intel VT-d) */
#define ACPI_DMAR_SIG  0x52414D44   /* "DMAR" little-endian */
#define ACPI_IVRS_SIG  0x53525649   /* "IVRS" little-endian */

/*
 * iommu_detect() — scan ACPI tables for DMAR (VT-d) or IVRS (AMD-Vi).
 * Returns the type found, or IOMMU_NONE.
 * Must be called before iommu_init().
 */
iommu_type_t iommu_detect(void);

/*
 * iommu_init() — configure IOMMU hardware for DMA isolation.
 * If no hardware IOMMU is present, falls back to soft-isolation mode
 * (page table accounting without hardware enforcement — useful for QEMU
 * and older hardware, but explicitly flagged as NOT SECURE).
 */
void iommu_init(void);

/*
 * iommu_create_domain() — create an isolation domain for a GPU partition.
 * phys_base/phys_limit define the HBM range this partition is allowed
 * to DMA into/from. Any access outside this range triggers an IOMMU fault.
 *
 * Returns domain_id (0..IOMMU_MAX_DOMAINS-1) or UINT32_MAX on failure.
 */
uint32_t iommu_create_domain(uint64_t phys_base, uint64_t phys_limit);

/*
 * iommu_map_range() — add a physical range to a domain's IOPT.
 * Called after iommu_create_domain() to populate the page table.
 */
int iommu_map_range(uint32_t domain_id, uint64_t phys_base, uint64_t size);

/*
 * iommu_bind_device() — associate the GPU PCI function with a domain.
 * After this, all DMA from bus:slot:func is validated against domain_id's IOPT.
 */
int iommu_bind_device(uint32_t domain_id, uint8_t bus, uint8_t slot, uint8_t func);

/*
 * iommu_status() — dump isolation status to VGA/serial for diagnostics.
 */
void iommu_status(void);

/*
 * iommu_is_hardware_enforced() — returns 1 if REAL hardware isolation is
 * active, 0 if running in soft-only mode. Callers should surface this
 * prominently so users know when they are NOT secure.
 */
uint8_t iommu_is_hardware_enforced(void);

extern iommu_state_t g_iommu;

#endif /* IOMMU_H */
